cp header.txt .placeholder
dd if=/dev/zero bs=1M count=1500 >>.placeholder
